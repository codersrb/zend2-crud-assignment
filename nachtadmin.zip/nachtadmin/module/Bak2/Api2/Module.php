<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Api for the canonical source repository
 * @copyright Copyright (c) 2005-2015 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */

namespace Api;

use Zend\ModuleManager\Feature\AutoloaderProviderInterface;
use Zend\Mvc\ModuleRouteListener;
use Zend\Mvc\MvcEvent;

class Module implements AutoloaderProviderInterface
{
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
		    // if we're in a namespace deeper than one level we need to fix the \ in the path
                    __NAMESPACE__ => __DIR__ . '/src/' . str_replace('\\', '/' , __NAMESPACE__),
                ),
            ),
        );
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }

    public function onBootstrap(MvcEvent $e)
    {
        $app = $e->getApplication();
        $app->getEventManager()->attach('render', array($this, 'registerJsonStrategy'), 100);
        // You may not need to do this if you're doing it elsewhere in your
        // application
        $eventManager        = $e->getApplication()->getEventManager();
        $moduleRouteListener = new ModuleRouteListener();
        $moduleRouteListener->attach($eventManager);
    }
    
    
    public function registerJsonStrategy($e)
    {
        $app          = $e->getTarget();
        $locator      = $app->getServiceManager();
        $view         = $locator->get('Zend\View\View');
        $phpStrateogy = $locator->get('Zend\View\Strategy\PhpRendererStrategy');
        // or any you have setup in your config...
        $jsonStrategy = $locator->get('ViewJsonStrategy');
    
        $routeMatch = $e->getRouteMatch();
        /* @var $routeMatch \Zend\Mvc\Router\RouteMatch */
        if(!empty($routeMatch)){
            $routeName = $routeMatch->getMatchedRouteName();
            if($routeName == 'bar') {
                // possible change layout?
                //$controller->layout('app/layout/new_layout');
                // Attach strategy, which is a listener aggregate, at high priority
                $view->getEventManager()->attach($jsonStrategy , 100);
                //             $view->getEventManager()->attach($phpStrateogy, 1);
            }
        }
    }
}
