<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Api\Controller\Api' => 'Api\Controller\ApiController',
            'Api\Controller\Bar' => 'Api\Controller\BarController',
            'Api\Controller\User' => 'Api\Controller\UserController',
        ),
    ),
    'router' => array(
        'routes' => array(
//             'api' => array(
//                 'type' => 'Segment',
//                 'options' => array(
//                     'route' => '/api/api[/:id]',
//                     'defaults' => array(
//                         'controller' => 'Api\Controller\Api'
//                     )
//                 )
//             ),
//             'may_terminated' => true,
//             'child_routes' => array(
                'bar-api' => array(
                    'type' => 'Segment',
                    'options' => array(
                        'route' => '/api/bar[/:id]',
                        'defaults' => array(
                            'controller' => 'Api\Controller\Bar'
                        )
                    )
                ),
                'user-api' => array(
                    'type' => 'Segment',
                    'options' => array(
                        'route' => '/api/user[/:id]',
                        'defaults' => array(
                            'controller' => 'Api\Controller\User'
                        )
                    )
                ),
            
            
//             )
        ),
    ),
    'view_manager' => array(
        'template_path_stack' => array(
            'Api' => __DIR__ . '/../view',
        ),
    ),
);
