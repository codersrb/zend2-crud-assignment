<?php
namespace Api\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
// use Admin\Model\FriendTable;
// use Admin\Model\UserTable;

class FriendController extends AbstractRestfulController
{
    public function create($data){
        //TODO: handle multiple
        // fb_username, 
    }
    
    
    /**
     * @return \Admin\Model\UserTable
     */
    protected function getUserTable(){
        return $this->getServiceLocator()->get('Admin\Model\UserTable');
    }
    
    
    /**
     * @return \Admin\Model\FriendTable
     */
    protected function getFriendTable(){
        return $this->getServiceLocator()->get('Admin\Model\FriendTable');
    }
}