<?php
namespace Api\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;

class BarController extends AbstractRestfulController
{

    /**
     * (non-PHPdoc)
     * 
     * @see \Zend\Mvc\Controller\AbstractRestfulController::get()
     */
    public function get($id)
    {
        $aOutput = array();
        
        try{
            $aOutput['bars'] = $this->getBarTable()->select(array('barid'=>$id))->toArray();
            $aOutput['result']= true;
            $aOutput['messages'] = array();
        }catch (\Exception $e){
            $aOutput['result']= false;
            $aOutput['messages']= $e->getMessage();
        }
        
        
        return new JsonModel(array($aOutput));
    }

    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::getList()
     */
    public function getList()
    {
        $aOutput = array();
        
        try{
            $aOutput['bars'] = $this->getBarTable()->select()->toArray();
            $aOutput['result']= true;
            $aOutput['messages'] = array();
        }catch (\Exception $e){
            $aOutput['result']= false;
            $aOutput['messages']= $e->getMessage();
        }
        return new JsonModel($aOutput);
    }

    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::create()
     */
//     public function create($data){}

    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::delete()
     */
//     public function delete($id)
//     {}

    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::update()
     */
//     public function update($id, $data)
//     {}

    /**
     * @return \Admin\Model\BarTable
     */
    protected function getBarTable(){
      return $this->getServiceLocator()->get('Admin\Model\BarTable');
    }
}
