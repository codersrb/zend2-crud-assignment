<?php
namespace Api\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\View\Model\ViewModel;

class UserController extends AbstractRestfulController
{

    public function create($data)
    {
        // TODO: Apply filter
        $iInsertId = $this->getUserTable()->insert($data);
        
        return new JsonModel(array(
            'userid' => $iInsertId
        ));
    }
    
    
    public function get($id){        
        return new JsonModel($this->getUserTable()->select(array('userid'=>$id))->toArray());
    }
    
    
    public function getList(){
        return new JsonModel($this->getUserTable()->select()->toArray());
    }
    
    
    /**
     *
     * @return \Admin\Model\UserTable;
     */
    protected function getUserTable()
    {
        return $this->getServiceLocator()->get('Admin\Model\UserTable');
    }
}