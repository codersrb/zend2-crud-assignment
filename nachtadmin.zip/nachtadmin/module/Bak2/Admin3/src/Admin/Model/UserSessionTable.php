<?php
namespace Admin\Model;

use Zend\Db\Adapter\AdapterAwareInterface;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Expression;
use Zend\Db\Sql\Having;

class UserSessionTable extends AbstractTableGateway implements AdapterAwareInterface
{

    public  $table = 'tbl_session';

    protected $lat, $lng, $distance;

    public function __construct($adapter = '')
    {
        if (! $this->adapter) {
            $this->setDbAdapter($adapter);
        }
    }

    public function setDbAdapter(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->initialize();
    }

    /**
     *
     * @param float $lat            
     * @param float $lng            
     * @param int $distance
     *            distance in KM
     */
    public function getNearestUsers($lat, $lng, $distance = 5)
    {
        $this->lat = $lat;
        $this->lng = $lng;
        $this->distance = $distance;
        
        return $aUsers = $this->select(function (Select $select) {
            
            $select->columns(array(
                'userid',
                'distance' => new Expression('(
                                          6371 * ACOS(
                                            COS(RADIANS(' . $this->lat . ')) * COS(RADIANS(lat)) * COS(
                                              RADIANS(lng) - RADIANS(' . $this->lng . ')
                                            ) + SIN(RADIANS(' . $this->lat . ')) * SIN(RADIANS(lat))
                                          )
                                        )')
            ))
            ->join(array('u'=> 'tbl_users'), 'u.userid = '.$this->table.'.userid' , array('fbid', 'email', 'fullname', 'fname', 'lname'))
            
            
            ;
            
            $having = new Having();
            $having->lessThanOrEqualTo('distance', 50000);
            $select->having($having)
                ->order('u.userid ASC, distance ASC ')
                ->limit(20);
        })
            ->toArray();
    }
}
