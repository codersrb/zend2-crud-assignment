<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/Admin for the canonical source repository
 * @copyright Copyright (c) 2005-2014 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Authentication\AuthenticationService;
use Admin\Forms\LoginForm;
use Common\Authentication\Adapter\AdminAuth as AuthAdapter;

class IndexController extends AbstractActionController
{

    protected $auth;

    public function __construct()
    {
        if (! $this->auth instanceof AuthenticationService) {
            $this->auth = new AuthenticationService();
        }
    }

    public function indexAction()
    {
        if (! $this->auth->hasIdentity()) {
            $this->redirect()->toRoute('admin-login');
        }
        
        $aViewData = array();
        
        //
        
        // Latest 8 users
        $aViewData['latestusers'] = $this->getUserTable()->getLatestUsers();
        $aViewData['countNewMember'] = $this->getUserTable()->getCountNewMember();
        $aViewData['avgOpenPerUser'] = $this->getUserSessionTable()->getAvarageOpenPerUser();
        $aViewData['avgSpentPerUser'] = $this->getUserSessionTable()->getAvarageSpentPerUser();
        $aViewData['avgClickOnBarPerUser'] = $this->getUserClickBarTable()->avgClickOnBarPerUser();
        
        return $aViewData;
    }

    public function loginAction()
    {
        if ($this->auth->hasIdentity()) {
            $this->redirect()->toRoute('home');
        }
        
        $aErrors = array();
        
        $this->layout('AdminLTE/login');
        $oLoginForm = new LoginForm();
        
        if ($this->getRequest()->isPost()) {
            
            $aLoginData = $this->getRequest()
                ->getPost()
                ->toArray();
            
            // validate
            $oLoginForm->setInputFilter($this->getAdminTable()
                ->loginFilter());
            
            $oLoginForm->setData($aLoginData);
            
            if ($oLoginForm->isValid()) {
                // valid form, now login to system
                $data = $oLoginForm->getData();
                
                $authAdapter = new AuthAdapter($data['uname'], $data['passwd'], $this->getAdminTable());
                $result = $this->auth->authenticate($authAdapter);
                
                // check if credential is invalid
                if (! $result->isValid()) {
                    $aErrors = $result->getMessages();
                } else {
                    $this->flashMessenger()->addMessage('Logged In');
                    return $this->redirect()->toRoute('home');
                }
            } else {
                $aErrors = $oLoginForm->getMessages();
            }
        }
        
        return array(
            'loginForm' => $oLoginForm,
            'aErrors' => $aErrors
        );
    }

    public function logoutAction()
    {
        if ($this->auth->hasIdentity()) {
            $this->auth->clearIdentity();
        }
        $this->flashMessenger()->addErrorMessage('Successfully logged out');
        
        return $this->redirect()->toRoute('home');
    }

    /**
     *
     * @return \Admin\Model\AdminTable
     */
    protected function getAdminTable()
    {
        return $this->getServiceLocator()->get('Admin\Model\AdminTable');
    }

    /**
     *
     * @return \Admin\Model\UserTable
     */
    protected function getUserTable()
    {
        return $this->getServiceLocator()->get('Admin\Model\UserTable');
    }

    /**
     *
     * @return \Admin\Model\UserSessionTable
     */
    protected function getUserSessionTable()
    {
        return $this->getServiceLocator()->get('Admin\Model\UserSessionTable');
    }

    /**
     *
     * @return \Admin\Model\UserClickBarTable
     */
    protected function getUserClickBarTable()
    {
        return $this->getServiceLocator()->get('Admin\Model\UserClickBarTable');
    }
}
