<?php
namespace Admin\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Zend\Authentication\AuthenticationService;
use Admin\Forms\EditBarForm;
use Zend\Validator\File\IsImage;
use Zend\Validator\File\Size;
use Zend\File\Transfer\Adapter\Http;

/**
 * BarController
 *
 * @author
 *
 * @version
 *
 */
class BarController extends AbstractActionController
{

    protected $auth;

    public function __construct()
    {
        if (! $this->auth instanceof AuthenticationService) {
            $this->auth = new AuthenticationService();
        }
    }

    /**
     * The default action - show the home page
     */
    public function indexAction()
    {
        if (! $this->auth->hasIdentity()) {
            $this->redirect()->toRoute('admin-login');
        }
        // TODO Auto-generated BarController::indexAction() default action
        
        // $this->getBarTable()->select()->toArray();
        return new ViewModel(array(
            'bars' => $this->getBarTable()
                ->getBars()
        ));
    }

    public function addAction()
    {
        if (! $this->auth->hasIdentity()) {
            $this->redirect()->toRoute('admin-login');
        }
        
        $aErrors = array();
        
        // get the form
        $oEditBarForm = new EditBarForm();
        
        $request = $this->getRequest();
        
        if ($request->isPost()) {
            
            $aUnfilteredData = $request->getPost()->toArray();
            
            unset($aUnfilteredData['submit']);
            
            // TODO: Validate
            $aInsertData = $aUnfilteredData;
            
            $oEditBarForm->setInputFilter($this->getBarTable()
                ->getAddInputFilter());
            
            $oEditBarForm->setData($aUnfilteredData);
            
            // validate
            
            if ($oEditBarForm->isValid()) {
                
                // handle files
                $files = $request->getFiles()->toArray();
                
                $data['defaultphoto'] = $files['defaultphoto']['name'] != '' ? $files['defaultphoto']['name'] : null;
                
                try {
                    if ($data['defaultphoto'] !== null) {
                        $size = new Size(array(
                            'max' => 2048000
                        ));
                        $isImage = new IsImage();
                        $filename = $data['defaultphoto'];
                        
                        $adapter = new Http();
                        $adapter->setValidators(array(
                            $size,
                            $isImage
                        ), $filename);
                        
                        if (! $adapter->isValid($filename)) {
                            $errors = array();
                            foreach ($adapter->getMessages() as $key => $row) {
                                $errors[] = $row;
                            }
                            $oEditBarForm->setMessages(array(
                                'avatar' => $errors
                            ));
                        }
                        
                        $destPath = 'public/uploads/images/';
                        $adapter->setDestination($destPath);
                        
                        $fileinfo = $adapter->getFileInfo();
                        preg_match('/.+\/(.+)/', $fileinfo['defaultphoto']['type'], $matches);
                        $extension = $matches[1];
                        $newFilename = sprintf('%s.%s', sha1(uniqid(time(), true)), $extension);
                        // Debug::dump($newFilename,$label='New file name',$echo=true);
                        $adapter->addFilter('File\Rename', array(
                            'target' => $destPath . $newFilename,
                            'overwrite' => true
                        ));
                        
                        if ($adapter->receive($filename)) {
                            
                            // FIXME: SET DYNAMIC URI
                            $aInsertData['defaultphoto'] = 'http://www.nachtadmin.com/uploads/images/' . $newFilename;
                        } else {
                            $aErrors = $adapter->getMessages();
                        }
                    }
                    
                    $iInsertId = $this->getBarTable()->insert($aInsertData);
                    return $this->redirect()->toRoute('bar-admin');
                } catch (\Exception $e) {
                    
                    $aErrors = $e->getMessages();
                }
            } else {
                $aErrors = $oEditBarForm->getMessages();
            }
        }
        
        return array(
            'editBarForm' => $oEditBarForm
        );
    }

    public function editAction()
    {
        $oEditBarForm = new EditBarForm();
        
        return array(
            'editBarForm' => $oEditBarForm
        );
    }

    /**
     * Return existing Bar Table
     *
     * @return \Admin\Model\BarTable | NULL
     */
    protected function getBarTable()
    {
        return $this->getServiceLocator()->get('Admin\Model\BarTable');
    }
}