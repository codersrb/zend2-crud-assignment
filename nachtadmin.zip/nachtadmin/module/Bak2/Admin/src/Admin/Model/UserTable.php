<?php
namespace Admin\Model;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\AdapterAwareInterface;
use Zend\Db\Adapter\Adapter;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Expression;

class UserTable extends AbstractTableGateway implements AdapterAwareInterface
{
    protected $table = 'tbl_users';
    public $dayInterval = 1;
    
    public function setDbAdapter(Adapter $adapter){
        $this->adapter = $adapter;
        $this->initialize();
    }
    
    /**
     * Return latest 8 users
     * @return \Zend\Db\ResultSet\array
     */
    public function getLatestUsers()
    {
        return $this->select(function (Select $select) {
            $select->columns(array(
                'fbid' =>  new Expression('DISTINCT (fbid)'),
                'fullname', 
                'days'=> new Expression('datediff(NOW(), joiningdate)'),
                'joiningdate'
                ));
            $select->order('userid DESC')->limit(8)->where->isNotNull('fbid')->notEqualTo('fbid', '');
        })->toArray();
    }
    
    /**
     * Returns new user between specific day and today
     * @param number $dayInterval
     * @return int
     */
    public function getCountNewMember($dayInterval = 1){
        $this->dayInterval = $dayInterval;
       $aUsers =  $this->select(function (Select $select) {
            $select->columns(array(
                'fbid' =>  new Expression('DISTINCT (fbid)'),
                'days'=> new Expression('datediff(NOW(), joiningdate)'),
            ));
            $select->order('userid DESC')->having->lessThanOrEqualTo('days', $this->dayInterval);
            $select->where->isNotNull('fbid')->notEqualTo('fbid', '');
        })->toArray();
        
        return count($aUsers);
    }
    
}