<?php
namespace Api\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\Db\Sql\Expression;

class UserSessionController extends AbstractRestfulController
{

    public function create($data){
        $aOutput = array();
        try{
            $this->getUserSessionTable()->insert($data);
            $aOutput['result']=true;
            $aOutput['sessionid']=$this->getUserSessionTable()->lastInsertValue;
            $aOutput['messages'] = array();
        
        } catch (\Exception $e){
            $aOutput['result']=false;
            $aOutput['messages'] = $e->getMessage();
        }
        return new JsonModel($aOutput);
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::getList()
     */
    public function getList(){
        return new JsonModel(parent::getList());
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::get()
     */
    public function get($id){
        return new JsonModel(parent::get());
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::update()
     */
    public function update($id,$data){
        return new JsonModel(parent::update());
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::patch()
     */
    public function patch($id,$data){
//         return new JsonModel(parent::patch());
        $aOutput = array();
        try{
            $data['closetime'] = new Expression('NOW()');
            $this->getUserSessionTable()->update($data, array('sessionid'=>$id));
            $aOutput['result']=true;
            $aOutput['messages'] = array();
        
        } catch (\Exception $e){
            $aOutput['result']=false;
            $aOutput['messages'] = $e->getMessage();
        }
        return new JsonModel($aOutput);
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::delete()
     */
    public function patchList($data){
        return new JsonModel(parent::patchList($data));
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::delete()
     */
    public function delete($id){
        return new JsonModel(parent::delete());
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::delete()
     */
    public function deleteList(){
        return new JsonModel(parent::deleteList());
    }
    
    
    /**
     * 
     * @return \Admin\Model\UserSessionTable
     */
    protected function getUserSessionTable(){
        return $this->getServiceLocator()->get('Admin\Model\UserSessionTable');
    }
}