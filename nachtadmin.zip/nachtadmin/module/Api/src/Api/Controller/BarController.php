<?php
namespace Api\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;

class BarController extends AbstractRestfulController
{

    /**
     * (non-PHPdoc)
     *
     * @see \Zend\Mvc\Controller\AbstractRestfulController::get()
     */
    public function get($id)
    {
        $aOutput = array();
        
        try {
            $aOutput['bars'] = $this->getBarTable()->getBars($id);
            $aOutput['result'] = true;
            $aOutput['messages'] = array();
        } catch (\Exception $e) {
            $aOutput['result'] = false;
            $aOutput['messages'] = $e->getMessage();
        }
        
        return new JsonModel(array(
            $aOutput
        ));
    }

    /**
     * (non-PHPdoc)
     * 
     * @see \Zend\Mvc\Controller\AbstractRestfulController::getList()
     */
    public function getList()
    {
        $aOutput = array();
        
        try {
            $aOutput['bars'] = $this->getBarTable()->getBars();
            $aOutput['result'] = true;
            $aOutput['messages'] = array();
        } catch (\Exception $e) {
            $aOutput['result'] = false;
            $aOutput['messages'] = $e->getMessage();
        }
        return new JsonModel($aOutput);
    }

    /**
     * (non-PHPdoc)
     * 
     * @see \Zend\Mvc\Controller\AbstractRestfulController::create()
     */
    public function create($data)
    {
        return new JsonModel(parent::create());
    }

    /**
     * (non-PHPdoc)
     * 
     * @see \Zend\Mvc\Controller\AbstractRestfulController::delete()
     */
    public function delete($id)
    {
        return new JsonModel(parent::delete());
    }
    

    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::delete()
     */
    public function deleteList()
    {
        return new JsonModel(parent::deleteList());
    }

    /**
     * (non-PHPdoc)
     * 
     * @see \Zend\Mvc\Controller\AbstractRestfulController::update()
     */
    public function update($id, $data)
    {
        return new JsonModel(parent::update());
    }

    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::patch()
     */
    public function patch($id, $data)
    {
        return new JsonModel(parent::patch());
    }

    /**
     *
     * @return \Admin\Model\BarTable
     */
    protected function getBarTable()
    {
        return $this->getServiceLocator()->get('Admin\Model\BarTable');
    }
}
