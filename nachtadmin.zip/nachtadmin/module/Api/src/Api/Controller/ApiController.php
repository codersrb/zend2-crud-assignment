<?php
namespace Api\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;

class ApiController extends AbstractRestfulController
{
}
