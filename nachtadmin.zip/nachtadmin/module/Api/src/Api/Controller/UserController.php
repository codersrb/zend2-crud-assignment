<?php
namespace Api\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
use Zend\View\Model\ViewModel;

class UserController extends AbstractRestfulController
{

    /**
     * (non-PHPdoc)
     *
     * @see \Zend\Mvc\Controller\AbstractRestfulController::create()
     */
    public function create($data)
    {
        $aOutput = array();
        try {
            
            $fbid = $data['fbid'];
            
            // TODO: Apply filter
            if (empty($fbid)) {
                $aOutput['result'] = false;
                $aOutput['messages'] = 'Invalid user details to add';
            } else {
                
                // check if existing user of same ID. Update him
                
                $aUser = $this->getUserTable()
                    ->select(array(
                    'fbid' => $fbid
                ))
                    ->current();
                
                if ($aUser) {
                    $data['lastseen']= date('Y-m-d H:i:s');
                    $this->getUserTable()->update($data, array(
                        'fbid' => $fbid
                    ));
                    
                    $aOutput['result'] = true;
                    $aOutput['userid'] = $aUser['userid'];
                    $aOutput['messages'] = array();
                } else {
                    
                    $data['joiningdate']= date('Y-m-d H:i:s');
                    $this->getUserTable()->insert($data);
                    $aOutput['result'] = true;
                    $aOutput['userid'] = $this->getUserTable()->lastInsertValue;
                    $aOutput['messages'] = array();
                }
            }
        } catch (\Exception $e) {
            $aOutput['result'] = false;
            $aOutput['messages'] = $e->getMessage();
        }
        return new JsonModel($aOutput);
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Zend\Mvc\Controller\AbstractRestfulController::get()
     */
    public function get($id)
    {
        return new JsonModel($this->getUserTable()
            ->select(array(
            'userid' => $id
        ))
            ->toArray());
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Zend\Mvc\Controller\AbstractRestfulController::getList()
     */
    public function getList()
    {
        return new JsonModel($this->getUserTable()
            ->select()
            ->toArray());
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Zend\Mvc\Controller\AbstractRestfulController::delete()
     */
    public function delete($id)
    {
        return new JsonModel(parent::delete($id));
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Zend\Mvc\Controller\AbstractRestfulController::delete()
     */
    public function deleteList()
    {
        return new JsonModel(parent::deleteList());
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Zend\Mvc\Controller\AbstractRestfulController::update()
     */
    public function update($id, $data)
    {
        return new JsonModel(parent::update());
    }

    /**
     * (non-PHPdoc)
     *
     * @see \Zend\Mvc\Controller\AbstractRestfulController::patch()
     */
    public function patch($id, $data)
    {
        return new JsonModel(parent::patch());
    }

    /**
     *
     * @return \Admin\Model\UserTable;
     */
    protected function getUserTable()
    {
        return $this->getServiceLocator()->get('Admin\Model\UserTable');
    }
}