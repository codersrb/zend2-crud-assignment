<?php
namespace Api\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;
// use Admin\Model\FriendTable;
// use Admin\Model\UserTable;

class FriendController extends AbstractRestfulController
{
    public function create($data){
        //TODO: handle multiple
        // fb_username, 
    }
    

    /**
     * (non-PHPdoc)
     *
     * @see \Zend\Mvc\Controller\AbstractRestfulController::delete()
     */
    public function delete($id)
    {
        return new JsonModel(parent::delete());
    }
    
    /**
     * (non-PHPdoc)
     *
     * @see \Zend\Mvc\Controller\AbstractRestfulController::update()
     */
    public function update($id, $data)
    {
        return new JsonModel(parent::update());
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::patch()
     */
    public function patch($id, $data)
    {
        return new JsonModel(parent::patch());
    }
    
    
    /**
     * @return \Admin\Model\UserTable
     */
    protected function getUserTable(){
        return $this->getServiceLocator()->get('Admin\Model\UserTable');
    }
    
    
    /**
     * @return \Admin\Model\FriendTable
     */
    protected function getFriendTable(){
        return $this->getServiceLocator()->get('Admin\Model\FriendTable');
    }
}