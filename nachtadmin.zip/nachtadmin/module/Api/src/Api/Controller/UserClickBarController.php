<?php
namespace Api\Controller;

use Zend\Mvc\Controller\AbstractRestfulController;
use Zend\View\Model\JsonModel;


class UserClickBarController extends AbstractRestfulController
{

    public function create($data){
        $aOutput = array();
        try{            
            $this->getUserClickBarTable()->insert($data);
            $aOutput['result']=true;
            $aOutput['clickid']=$this->getUserClickBarTable()->lastInsertValue;
            $aOutput['messages'] = array();
            
        } catch (\Exception $e){
            $aOutput['result']=false;
            $aOutput['messages'] = $e->getMessage();
        }
        return new JsonModel($aOutput);
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::getList()
     */
    public function getList(){
        return new JsonModel(parent::getList());
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::get()
     */
    public function get($id){
        return new JsonModel(parent::get());
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::update()
     */
    public function update($id,$data){
        return new JsonModel(parent::update());
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::patch()
     */
    public function patch($id,$data){
        return new JsonModel(parent::patch());
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::delete()
     */
    public function delete($id){
        return new JsonModel(parent::delete());
    }
    
    /**
     * (non-PHPdoc)
     * @see \Zend\Mvc\Controller\AbstractRestfulController::delete()
     */
    public function deleteList(){
        return new JsonModel(parent::deleteList());
    }
    
    
    
    /**
     * 
     * @return \Admin\Model\UserClickBarTable
     */
    protected function getUserClickBarTable(){
        return $this->getServiceLocator()->get('Admin\Model\UserClickBarTable');
    }
}