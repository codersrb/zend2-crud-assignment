<?php
/**
 * Zend Framework (http://framework.zend.com/)
 *
 * @link      http://github.com/zendframework/ZendSkeletonApplication for the canonical source repository
 * @copyright Copyright (c) 2005-2012 Zend Technologies USA Inc. (http://www.zend.com)
 * @license   http://framework.zend.com/license/new-bsd New BSD License
 */
return array(
    'service_manager' => array(
        'invokables' => array(
            'Common\Listeners\ApiErrorListener' => 'Common\Listeners\ApiErrorListener',
            'Common\Listeners\OAuthListener' => 'Common\Listeners\OAuthListener'
        )
    ),
//     'controller_plugins' => array(
//         'invokables' => array(
//             'ErrorMessagePlugin' => 'Common\Controller\Plugin\ErrorMessagePlugin',
//         )
//     ),
    'factories' => array(
        'Zend\Log\Logger' => function ($sm) {
            $logger = new Zend\Log\Logger();
            $writer = new Zend\Log\Writer\Stream('./data/log/' . date('Y-m-d') . '-error.log');
            
            $logger->addWriter($writer);
            
            return $logger;
        }
    ),
    
    'view_manager' => array(
        'display_not_found_reason' => true,
        'display_exceptions' => true,
        'doctype' => 'HTML5',
        'not_found_template' => 'error/404',
        'exception_template' => 'error/index',
        'template_map' => array(
            'layout/layout' => __DIR__ . '/../view/layout/layout.phtml',
            'common/index/index' => __DIR__ . '/../view/common/index/index.phtml',
            'error/404' => __DIR__ . '/../view/error/404.phtml',
            'error/index' => __DIR__ . '/../view/error/index.phtml'
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view'
        )
    )
);