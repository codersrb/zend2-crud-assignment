<?php
namespace Common\Controller\Plugin;

use Zend\Mvc\Controller\Plugin\AbstractPlugin;
use Zend\Form\Form;

/**
 *
 * @author user
 *        
 */
class ErrorMessagePlugin extends AbstractPlugin
{


    /**
     * Attachs api errors with specific form
     * @param array $errors
     * @param Form $oForm
     */
    public function bindWithForm($errors , $oForm){
        if($oForm instanceof Form && is_array($errors)){
            foreach($errors as $elemName => $errorMessage){
                $errorMessageArray = is_array($errorMessage)? $errorMessage : array($errorMessage);
                if($oForm->has($elemName)){
                     $oForm->get($elemName)->setMessages($errorMessageArray);
                }                
            }
        }
    }
}