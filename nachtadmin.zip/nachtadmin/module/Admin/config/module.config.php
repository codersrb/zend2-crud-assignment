<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Admin\Controller\Index' => 'Admin\Controller\IndexController',
            'Admin\Controller\Bar' => 'Admin\Controller\BarController'
        )
    ),
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Literal',
                'options' => array(
                    // Change this to something specific to your module
                    'route' => '/',
                    'defaults' => array(
                        // Change this value to reflect the namespace in which
                        // the controllers for your module are found
                        '__NAMESPACE__' => 'Admin\Controller',
                        'controller' => 'Index',
                        'action' => 'index'
                    )
                )
            ),
            'bar-admin' => array(
                'type' => 'Segment',
                'options' => array(
                    'route' => '/bar[/:action[/:id]]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id' => '[0-9]*'
                    ),
                    'defaults' => array(
                        '__NAMESPACE__' => 'Admin\Controller',
                        'controller' => 'Bar',
                        'action' => 'index'
                    )
                )
            ),
            'admin-login' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/login',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Admin\Controller',
                        'controller' => 'Index',
                        'action' => 'login'
                    )
                )
            ),
            'logout' => array(
                'type' => 'Literal',
                'options' => array(
                    'route' => '/logout',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Admin\Controller',
                        'controller' => 'Index',
                        'action' => 'logout'
                    )
                )
            )
            
            
        )
    ),
    
    'di' => array(
        'services' => array(
            'Admin\Model\BarTable' => 'Admin\Model\BarTable',
            'Admin\Model\UserTable' => 'Admin\Model\UserTable',
            'Admin\Model\AdminTable' => 'Admin\Model\AdminTable',
            'Admin\Model\UserSessionTable' => 'Admin\Model\UserSessionTable',
            'Admin\Model\UserClickBarTable' => 'Admin\Model\UserClickBarTable',
        )
    ),
    
    'view_manager' => array(
        'template_path_stack' => array(
            'Admin' => __DIR__ . '/../view'
        ),
        
        'template_map' => array(
            'AdminLTE/login' => __DIR__ . '/../view/layout/login.phtml'
        )
    )
);
